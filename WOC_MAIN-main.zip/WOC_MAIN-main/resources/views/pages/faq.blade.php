@extends('layouts.main')
@section('description', '')
@section('keywords', '')
@section('title', '')
@section('content')


<!-- Breadcrumb Area -->
<section class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumb-contents">
                    <h2 class="page-title">FAQ&#39;s</h2>
                    <div class="breadcrumb">
                        <ul>
                            <li>
                                <a href="{{ route('home') }}">Home</a>
                            </li>
                            <li class="active">
                                <a href="#">FAQ&#39;s</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- end .col-md-12 -->
        </div><!-- end .row -->
    </div><!-- end .container -->
</section><!-- ends: .breadcrumb-area -->


<section class="faq-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form action="#" class="search--doc">
                    <div class="form-group">
                        <input type="text" placeholder="Search Documentation">
                        <button type="submit">Search</button>
                    </div>
                </form>
            </div><!-- ends: .col-lg-12 -->
            <div class="col-lg-6">

                <div class="faq-box">
                    <div class="faq-head">
                        <h4>For Authors (45)</h4>
                    </div><!-- ends: .faq-head -->
                    <div class="faq-content">
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">How can I update a theme that is live on SHOP?</a>
                            </li>
                            <li>
                                <a href="#">How to write the changelog for theme updates?</a>
                            </li>
                            <li>
                                <a href="#">Do you have any guideline on item promotions?</a>
                            </li>
                            <li>
                                <a href="#">Why my item has been rejected?</a>
                            </li>
                            <li>
                                <a href="#">I’ve submitted an item, how much time will require to be live on?</a>
                            </li>
                            <li>
                                <a href="#">What links or texts can I put in the item description, demo and downloadable
                                    package?</a>
                            </li>
                        </ul>
                        <a href="#" class="link-more">View All Articles
                            <span class="icon icon-arrow-right-circle"></span>
                        </a>
                    </div><!-- ends: .faq-content -->
                </div><!-- ends: .faq-box -->

            </div><!-- ends: .col-lg-6 -->
            <div class="col-lg-6">

                <div class="faq-box">
                    <div class="faq-head">
                        <h4>For Customers (60)</h4>
                    </div><!-- ends: .faq-head -->
                    <div class="faq-content">
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">How can I update a theme that is live on SHOP?</a>
                            </li>
                            <li>
                                <a href="#">How to write the changelog for theme updates?</a>
                            </li>
                            <li>
                                <a href="#">Do you have any guideline on item promotions?</a>
                            </li>
                            <li>
                                <a href="#">Why my item has been rejected?</a>
                            </li>
                            <li>
                                <a href="#">I’ve submitted an item, how much time will require to be live on?</a>
                            </li>
                            <li>
                                <a href="#">What links or texts can I put in the item description, demo and downloadable
                                    package?</a>
                            </li>
                        </ul>
                        <a href="#" class="link-more">View All Articles
                            <span class="icon icon-arrow-right-circle"></span>
                        </a>
                    </div><!-- ends: .faq-content -->
                </div><!-- ends: .faq-box -->

            </div><!-- ends: .col-lg-6 -->
            <div class="col-lg-6">

                <div class="faq-box">
                    <div class="faq-head">
                        <h4>For Account (25)</h4>
                    </div><!-- ends: .faq-head -->
                    <div class="faq-content">
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">How can I update a theme that is live on SHOP?</a>
                            </li>
                            <li>
                                <a href="#">How to write the changelog for theme updates?</a>
                            </li>
                            <li>
                                <a href="#">Do you have any guideline on item promotions?</a>
                            </li>
                            <li>
                                <a href="#">Why my item has been rejected?</a>
                            </li>
                            <li>
                                <a href="#">I’ve submitted an item, how much time will require to be live on?</a>
                            </li>
                            <li>
                                <a href="#">What links or texts can I put in the item description, demo and downloadable
                                    package?</a>
                            </li>
                        </ul>
                        <a href="#" class="link-more">View All Articles
                            <span class="icon icon-arrow-right-circle"></span>
                        </a>
                    </div><!-- ends: .faq-content -->
                </div><!-- ends: .faq-box -->

            </div><!-- ends: .col-lg-6 -->
            <div class="col-lg-6">

                <div class="faq-box">
                    <div class="faq-head">
                        <h4>For Payment (20)</h4>
                    </div><!-- ends: .faq-head -->
                    <div class="faq-content">
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">How can I update a theme that is live on SHOP?</a>
                            </li>
                            <li>
                                <a href="#">How to write the changelog for theme updates?</a>
                            </li>
                            <li>
                                <a href="#">Do you have any guideline on item promotions?</a>
                            </li>
                            <li>
                                <a href="#">Why my item has been rejected?</a>
                            </li>
                            <li>
                                <a href="#">I’ve submitted an item, how much time will require to be live on?</a>
                            </li>
                            <li>
                                <a href="#">What links or texts can I put in the item description, demo and downloadable
                                    package?</a>
                            </li>
                        </ul>
                        <a href="#" class="link-more">View All Articles
                            <span class="icon icon-arrow-right-circle"></span>
                        </a>
                    </div><!-- ends: .faq-content -->
                </div><!-- ends: .faq-box -->

            </div><!-- ends: .col-lg-6 -->
        </div>
    </div>
</section><!-- ends: .faq-area -->


@endsection